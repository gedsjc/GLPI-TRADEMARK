# Trademark for GLPI >= 10.0

![Lint](https://github.com/librecodecoop/trademark/workflows/Lint/badge.svg)
[![CodeFactor](https://www.codefactor.io/repository/github/librecodecoop/trademark/badge)](https://www.codefactor.io/repository/github/librecodecoop/trademark)
[![Total Downloads](https://img.shields.io/github/downloads/librecodecoop/trademark/total.svg)](https://github.com/librecodecoop/trademark/releases)
[![Current Release](https://img.shields.io/github/release/librecodecoop/trademark.svg)](https://github.com/librecodecoop/trademark/releases/latest)

Allow customization of logos, background and custom CSSs

# Installation
 * Uncompress the archive to the `<GLPI_ROOT>/plugins/trademark` directory
 * Navigate to the Configuration > Plugins page,
 * Install and activate the plugin.
